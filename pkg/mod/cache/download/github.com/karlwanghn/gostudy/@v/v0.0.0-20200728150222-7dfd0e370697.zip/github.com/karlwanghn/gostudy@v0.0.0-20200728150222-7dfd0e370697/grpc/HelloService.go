package main

type HellloServer struct {
}

/**
*大写的Hello表式
 */
func (p *HellloServer) Hello(request string, respons string) error {

}
